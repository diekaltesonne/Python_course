# coursera-bot
An example of a bot implementation for Coursera course on Web Development with Python
