from django.http import HttpResponse
from django.views.decorators.http import require_http_methods
from django.shortcuts import render
import re
# Create your views here.

@require_http_methods(['GET', 'POST'])
def echo_0(request):
    if request.method == 'GET' and something == None:
        return render(request,'templates/echo.html',context)
    elif request.method in ['POST', 'PUT']:
        return HtppBadResponse(status=405)

def parser(string):
    result = re.match(r'[aA-zZ]+',string)
    return result.group(0)


def echo(request):
    try:
        meta = parser(request.META['QUERY_STRING'])
        return render(request, 'echo.html', context={
            'get_letters': meta,
            'get_value': request.GET.get(meta),
            'get_tag': request.META.get('HTTP_X_PRINT_STATEMENT'),
            'request_method': request.META['REQUEST_METHOD'].lower()
        })
    except:
        return HttpResponse(status=404)

#nothing
def filters(request):
    return render(request, 'filters.html', context={
        'a': request.GET.get('a', 1),
        'b': request.GET.get('b', 1)
    })

def extend(request):
    return render(request, 'extend.html', context={
        'a': request.GET.get('a'),
        'b': request.GET.get('b')
    })
